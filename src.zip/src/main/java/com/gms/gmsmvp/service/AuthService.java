package com.gms.gmsmvp.service;

import com.gms.gmsmvp.dto.LoginRequest;
import com.gms.gmsmvp.dto.LoginResponse;
import com.gms.gmsmvp.repository.UserRepository;
import com.gms.gmsmvp.security.GmsUserDetails;
import lombok.RequiredArgsConstructor;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.Map;

@Service
@RequiredArgsConstructor
public class AuthService {

    private final AuthenticationManager authenticationManager;
    private final JwtService jwtService;
    private final UserRepository userRepository;

    @Transactional
    public LoginResponse login(LoginRequest request) {
        Authentication authentication = authenticationManager.authenticate(
                new UsernamePasswordAuthenticationToken(request.getUsername(), request.getPassword())
        );

        GmsUserDetails principal = (GmsUserDetails) authentication.getPrincipal();
        userRepository.findByUsername(principal.getUsername()).ifPresent(user -> {
            user.setLastLoginAt(LocalDateTime.now());
            userRepository.save(user);
        });

        String token = jwtService.generateToken(principal, Map.of(
                "userId", principal.getId(),
                "role", principal.getRoleName(),
                "gymId", principal.getGymId() == null ? "" : principal.getGymId()
        ));

        return new LoginResponse(
                token,
                "Bearer",
                jwtService.getExpirationSeconds(),
                principal.getId(),
                principal.getUsername(),
                principal.getFullName(),
                principal.getRoleName(),
                principal.getGymId()
        );
    }
}
