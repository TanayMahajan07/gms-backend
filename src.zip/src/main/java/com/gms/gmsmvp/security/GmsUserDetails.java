package com.gms.gmsmvp.security;

import com.gms.gmsmvp.entity.User;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import java.util.Collection;
import java.util.List;

public class GmsUserDetails implements UserDetails {

    private final User user;

    public GmsUserDetails(User user) {
        this.user = user;
    }

    public Long getId() {
        return user.getId();
    }

    public String getFullName() {
        String lastName = user.getLastName() == null ? "" : " " + user.getLastName();
        return user.getFirstName() + lastName;
    }

    public String getRoleName() {
        return user.getRole().getRoleName();
    }

    public Long getGymId() {
        return user.getGymId();
    }

    @Override
    public Collection<? extends GrantedAuthority> getAuthorities() {
        return List.of(new SimpleGrantedAuthority("ROLE_" + getRoleName()));
    }

    @Override
    public String getPassword() {
        return user.getPasswordHash();
    }

    @Override
    public String getUsername() {
        return user.getUsername();
    }

    @Override
    public boolean isEnabled() {
        return user.getActive() == null || user.getActive();
    }
}
